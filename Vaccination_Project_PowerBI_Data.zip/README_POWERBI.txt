
VACCINATION PROJECT — POWER BI DATA

This folder contains five datasets prepared for Power BI.

1. coverage.csv
Contains vaccination coverage information including:
country, year, antigen, doses, coverage,
gender, education level, residence and population density.

2. incidence_rate.csv
Contains disease incidence information including:
country, year, disease and incidence rate.

3. reported_cases.csv
Contains reported disease cases by:
country, year and disease.

4. vaccine_introduction.csv
Contains vaccine introduction information including:
country, WHO region, year and vaccine.

5. vaccine_schedule.csv
Contains vaccination schedule information including:
vaccine, target population, geographical area,
age administered and schedule rounds.

IMPORTANT DATA NOTE:
This project uses a synthetic dataset structured according
to the variables specified in the project brief.

The data are intended for academic demonstration and analysis
and should NOT be interpreted as official WHO statistics.
